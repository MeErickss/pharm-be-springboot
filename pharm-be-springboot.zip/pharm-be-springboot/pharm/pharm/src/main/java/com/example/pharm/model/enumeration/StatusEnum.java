package com.example.pharm.model.enumeration;

public enum StatusEnum {
    ATIVO,
    INATIVO,
    BLOQUEADO;
}
