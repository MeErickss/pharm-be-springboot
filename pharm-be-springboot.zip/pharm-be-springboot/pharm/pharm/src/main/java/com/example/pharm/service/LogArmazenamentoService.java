package com.example.pharm.service;

import com.example.pharm.model.*;
import com.example.pharm.model.enumeration.StatusEnum;
import com.example.pharm.repository.LogArmazenamentoRepository;
import com.example.pharm.repository.UsuariosRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.List;

@Service
@Transactional
public class LogArmazenamentoService {
    private final LogArmazenamentoRepository logArmazenamentoRepository;
    private final UsuariosRepository usuariosRepository;

    public LogArmazenamentoService(LogArmazenamentoRepository logArmazenamentoRepository, UsuariosRepository usuariosRepository){
        this.logArmazenamentoRepository = logArmazenamentoRepository;
        this.usuariosRepository = usuariosRepository;
    }

    public Long contarLogAlarmes(){
        return logArmazenamentoRepository.count();
    }

    public void criarLogAlarmes(Long userId, String descricao, StatusEnum status){

        Usuario user = usuariosRepository.findById(userId).orElseThrow(()->
                new RuntimeException("Usuario '" + userId + "' não encontrado")
        );

        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());


        LogArmazenamento l = new LogArmazenamento();
        l.setStatus(status);
        l.setDescricao(descricao);
        l.setUser(user);
        l.setDatahora(timeStamp);
        logArmazenamentoRepository.save(l);
    }

    public List<LogArmazenamento> listAll(){
        return logArmazenamentoRepository.findAll();
    }

    public LogArmazenamento listId(Long id){
        return logArmazenamentoRepository.findById(id).orElseThrow(()->
                new RuntimeException("Status '" + id + "' não encontrado")
        );
    }
}
