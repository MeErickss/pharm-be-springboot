package com.example.pharm.dto;

public class LogAlarmesDto {
}
