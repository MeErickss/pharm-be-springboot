package com.example.pharm.dto;

public class FuncoesDto {
}
