package com.example.pharm.model.enumeration;

public enum FuncaoEnum {
}
