# **Atividades a se fazer**
### Padronizar o codigo
### Medidas de securança secureBoot SWT
### CRUD
### Linkar com o react.jsx