package com.example.pharm.model.enumeration;

public enum NivelEnum {
    ADMIN,
    MANUTENCAO,
    OPERADOR;
}
